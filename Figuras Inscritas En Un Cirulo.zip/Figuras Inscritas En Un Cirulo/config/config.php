<?php
// config.php
require 'vendor/autoload.php';

\Stripe\Stripe::setApiKey('sk_test_51QORLeEUWIt9tPpJlokZk1kLj71leonXJ3KkBjLRXH0hSwapOSNs3gEgO2tpRKK2PXa4fdhSizNIOXm4KrfO4R6j00PjEhmD1U');
?>